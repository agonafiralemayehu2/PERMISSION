readne for hello world folder
